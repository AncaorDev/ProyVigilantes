$(document).ready(function(){
	$("#change_theme").change(function(){
		$(this).prop('selectedIndex',0);
		alert("Esta funcion aun esta en desarrollo,\n mas información en los detalles de versión")
	})
})